Transrapid Track Set BETA 1.1 README
==================================



CONTENTS
========
1. Introduction
2. License
3. Compatibility
4. Parameter Settings
5. Installation
6. Credits
7. Technical Details



1. INTRODUCTION
===============
The TransRapid Track Set is a maglev track replacement set. The Transrapid system is a German high-speed monorail train system using magnetic levitation. The tracks in this set are based upon their real life equivalents at the test facility for the system in Emsland, Germany.



2. LICENSE
==========
This set is available under the
Creative Commons Attribution-Noncommercial-Share Alike 3.0 Netherlands
license.

This means that you can do whatever you like, as long as you credit the author of the set, your intentions remain non-commercial and release any work based on (parts of) this set under the same license (CC BY-NC-SA NL).

For more information, including the full license text in various languages, visit: http://creativecommons.org/licenses/by-nc-sa/3.0/nl/deed.en



3. COMPATIBILITY
================
This NewGRF replacement set is compatible with both TTDPatch and OpenTTD. If you experience any troubles while using this set, please upgrade to the latest version of the game (preferrably a nightly version) and the latest version of this set, before searching for support in the TransRapid Track Set topic on tt-forums.net (http://www.tt-forums.net/viewtopic.php?f=26&t=34753).

The TransRapid Track Set has support for both the default TTD terrain/climates as well as the OpenGFX Terrain Set. The climate is detected automatically. In case detection of the OpenGFX Terrain Set fails, you can enable support manually by means of a parameter setting.

Due to limitations within the game, the TransRapid Track Set remains incompatible with other bridge sets/grfs. Use other bridge grfs at own risk of weird behaviour.



4. PARAMETER SETTINGS
=====================
By default, the TransRapid Track Set disables the fences which are usually put next to railroad, monorail and maglev tracks due to aesthetic reasons. You can re-enable those fences by setting the first parameter value to 1.
E.g.: TransRapidTrackSetW.grf 1

In case detection of the OpenGFX Terrain Set fails, you can enable support manually by setting the second parameter setting to value 1 to force OpenGFX Terrain support.
E.g.: TransRapidTrackSetW.grf 0 1
Which keeps fences disabled and forces OpenGFX Terrain support.



5. INSTALLATION
===============
> DOS or Windows Version?

You can tell by looking at the filename of TTD's original graphics. trg1.grf indicates the DOS version, while trg1r.grf indicates the Windows version. Depending on that fact, you need either the DOS version or the Windows version of the TransRapid Track Set.
    DOS Version:   traratrk.grf
Windows Version:   TransRapidTrackSetW.grf


> TTDPatch Installation

Copy the grf file to to your TTDPatch\newgrf directory. Create the directory if it doesn't exist already.
After that, open newgrf.cfg (in case of DOS version) or newgrfw.cfg (in case of Windows version) using Notepad or your favourite plain text editor. Add 'newgrf\traratrk.grf' or 'newgrf\TransRapidTrackSetW.grf' on a new line (without quotes) and save the changes you made. Start TTDPatch and you're ready to go.


> OpenTTD Installation

Copy the grf file to to your \data\newgrf [*] directory. Create the directory if it doesn't exist already (yes, you could drop it right in \data, but it's good practise to keep the default and custom graphic files apart). Start OpenTTD and click NewGRF Settings in the title screen. Click the Add button, select 'TransRapid Track Set' and click Add to selection. Close the NewGRF Settings window. That's it.

[*] The data directory is either located in your %UserProfile%/Documents directory or the OpenTTD installation directory.



6. CREDITS
==========
The TransRapid Track Set is developed, drawn and coded by FooBar (Jasper Vries).

The TransRapid Track Set contains (parts of) graphical work by other artists.

Special thanks goes out to Zephyris (Richard Wheeler) for his work on the OpenGFX set of which I was able to use the station platform texture (and of course the terrain sprites in order to make OpenGFX support possible).

The original TTD graphics are drawn by Simon Foster. Without his great artistical work TTD most likely wouldn't have been the great game as it still is nowadays. I didn't ask him for permission to use the TTD terrain sprites, but I'm sure he wouldn't mind me making a great game even better.



7. SUPPORT
==========
For technical support, send a personal message to 'FooBar' at the Transport Tycoon Forums (www.tt-forums.net), or ask you question in the TransRapid Track Set topic on tt-forums.net (http://www.tt-forums.net/viewtopic.php?f=26&t=34753). 



8. TECHNICAL DETAILS
====================
Set name:    TransRapid Track Set
Version:     BETA 1.1 (2008/08/11)
File names:  TransRapidTrackSetW.grf
             traratrk.grf
GRF-ID:      FB FB 02 01
License:     CC BY-NC-SA NL
