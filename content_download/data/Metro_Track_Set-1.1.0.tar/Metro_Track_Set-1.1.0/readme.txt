  //////////////////////////////////////////////////////////////////////////////
 ////////////////////////////// METRO TRACK SET ///////////////////////////////
//////////////////////////////////////////////////////////////////////////////

The Metro Track Set adds third rail tracks to OpenTTD and TTDPatch and is
originally designed to complement the metros of the 2cc Trainset. It can 
add Metro Tracks as a new railtype or at your option replace monorail or
maglev with Metro Tracks instead.

Version:  Metro Track Set 1.1.0
GRF-ID:   FB FB 04 02
MD5 hash: c5d462b520ed5eeb3af5619da165da35  metrotrk.grf


0. Contents
================================================================================
1. License Information
2. Background Information
3. Game Version Requirements
4. OpenTTD Railtypes Support
5. Parameter Options
	5.1 First Parameter
	5.2 Second Parameter
	5.3 Setting the Parameter Options
6. Terrain and Road Set Compatibility
7. Track Set Compatibility
	7.1 NuTracks
8. Train Set Compatibility
9. Upgrading From Previous Version
A. Credits
B. Frequently Asked Questions
C. Obtaining the Source



1. License Information
================================================================================
The Metro Track Set is available according to the GNU General Public License
version 2.0. For more information, see the file "license.txt". 

    Metro Track Set for OpenTTD and TTDPatch
    Copyright (C) 2010  Metro Track Set Developers (see section A below)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License version 2, 
	as published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



2. Background Information
================================================================================
The system used in this set is commonly known as a 'bottom contact third rail',
where the third rail sits at either side of the running rails and is slightly
elevated above the ground (in the order of a foot (30 cm) or something). This
type of third rail has a protective cover on top of the live rail preventing
direct contact and therefore limiting the risk of electrocution.
This set is inspired by the Dutch metro systems of Amsterdam and Rotterdam which
both use the type of third rail as described above (and where the protective
cover is in fact yellow).



3. Game Version Requirements
================================================================================
Metro Track Set is supposed to work on both OpenTTD and TTDPatch, though not all
features are available in all game versions.

To be able to use all features, OpenTTD 1.0.3 (or higher) or OpenTTD trunk
r20242 (or higher) is required.

A limited set of features is available on older versions of OpenTTD and on
TTDPatch nightly r2334 (or higher).

Metro Track Set is not TTDPatch older than nightly r2334. The first supported
version of OpenTTD is unknown.



4. OpenTTD Railtypes Support
================================================================================
The Metro Track Set supports OpenTTD's railtypes feature. Support for this is
automatically enabled in case of OpenTTD r20242 or higher (this includes OpenTTD
1.0.3). In case of railtypes, the Metro Track Set adds two additional track
types. One track type is third rail powered and has rail type label 3RDR, the
other track type has both third rail and overhead catenary power and has rail
type label 3RDC. Whether this is usable for you depends on the vehicle set you 
are using. 

If you find your metro vehicles running on monorail or maglev track, you might
want to consider setting the appropriate track type parameter (see next
section). In that case, monorail or maglev tracks are replaced by the Metro
Track Set (rather than adding an additional track type) and the rail type label
MONO respectively MGLV is used instead.

If you don't want to use the third rail with catenary tracks, you can disable it
by setting a parameter (see next section).

Furthermore, with railtypes, the Metro Track Set is automatically compatible
with any terrain or road set.



5. Parameter Options
================================================================================
There are two parameters which can be useful. The first parameter controls 
visual aspects of the Metro Track Set. The second parameter controls technical 
aspects of the track type.


5.1 First Parameter
--------------------------------------------------------------------------------
This parameter controls how the tracks look in the game. The options of this
parameter are listed in the table below.

---------------------------------------------------------------
|Bit|Value|Enables                                            |
---------------------------------------------------------------
| - |   0 | OpenGFX terrain, tracks and GUI support (default) |
| 0 |   1 | TTD terrain, tracks and GUI support               |
| 1 |   2 | Extra-snowy OpenGFX style tracks (Railtypes only) |
---------------------------------------------------------------

Example:
If you use the TTD base graphics, set the first parameter value to 1.


5.2 Second Parameter
--------------------------------------------------------------------------------
This parameter controls how the tracks are added to the game. The behaviour of
this parameter depends on the platform used (OpenTTD or TTDPatch) and platform
version. Only one value from the table below can be set at any time.

-----------------------------------------------------------------------------------------------
|Value|Behaviour OpenTTD >= r20242 (>= 1.0.3)         |Behaviour TTDPatch and OpenTTD < r20242|
-----------------------------------------------------------------------------------------------
|   0 | Add 3RDR railtype (default)                   | Replace monorail tracks (default)     |
|   1 | Replace MONO (monorail) railtype              | [option has no effect]                |
|   2 | Replace MGLV (maglev) railtype                | Replace maglev tracks                 |
|   4 | Replace monorail tracks (don't use railtypes) | [option has no effect]                |
|   6 | Replace maglev tracks (don't use railtypes)   | Replace maglev tracks                 |
|   8 | Disable 3RDC (third rail + catenary) railtype | [option has no effect]                |
|   9 | Disable 3RDC and replace MONO                 | [option has no effect]                |
|  10 | Disable 3RDC and replace MGLV                 | Replace maglev tracks                 |
-----------------------------------------------------------------------------------------------

Example:
If you don't want the options of the first parameter, but do want to replace the
maglev tracks with Metro Tracks, set the first parameter to 0 and the second
parameter to 2.

Debug: Add 16 to the value of the second parameter to enable debug mode. This
moves the default "Kirby Paul Tank" and "Chaney 'Jubilee'" engines to 3RDR and
3RDC respectively in all climates, thus enabling the otherwise disabled new
track types if there are no native vehicles for it available.


5.3 Setting the Parameter Options
--------------------------------------------------------------------------------
How to set the parameter options depends on platform and version.

5.3.1 OpenTTD r20258 and newer (=> 1.1.x)

Go to NewGRF Settings and make sure Metro Track Set is in the list of Active
NewGRF files. Select Metro Track Set from that list and click Set parameters.
A convenient GUI appears to make all settings in a human-readable fashion. All
features listed above are available through a number of settings.

5.3.2 OpenTTD r20257 and older (<= 1.0.x)

Go to NewGRF Settings and make sure Metro Track Set is in the list of active
NewGRF files. Select Metro Track Set from that list and click Set parameters.
Type the values for the first and second parameter in the box (in that order) 
separated by a space. If you don't want the options of the first parameter, type
a zero (0), followed by a space and the value for the second parameter.

5.3.2 TTDPatch

After the entry for Metro Track Set in your newgrf[w].cfg file, type a space and
then the values for the first and second parameter in the box (in that order) 
separated by a space. If you don't want the options of the first parameter, type
a zero (0) for this parameter. Example (TTD terrain replacing maglev):
metrotrk.grf 1 2



6. Terrain and Road Set Compatibility
================================================================================
The Metro Track Set has native support for the OpenGFX and TTD base graphic
sets. The OpenGFX graphics style is enabled by default. The TTD graphics style
can be enabled by a parameter setting, see section 5.
Support for third party road sets might be added in the future.



7. Track Set Compatibility
================================================================================
The Metro Track Set can be loaded together with other track sets in OpenTTD 
>= r20242 (>= 1.0.3).
If other track sets don't define 3RDR and 3RDC rail types, these will be defined
by Metro Track Set (assuming default settings). If other track sets do define
these rail types, these sets incrementally overwrite each others properties and
graphics, ultimately the last loaded set "wins".

7.1 NuTracks
--------------------------------------------------------------------------------
Special compatibility has been implemented for NuTracks. If both Metro Track Set
and NuTracks are active, NuTracks will define the 3RDR and 3RDC track properties
and Metro Track Set will supply the graphics.
Additionally, setting Metro Track Set to replace MONO or MGLV with railtypes
enabled will have no effect while NuTracks is active. Disabling Metro Track 
Set's railtype feature is not recommended with NuTracks active and is 
unsupported by Metro Track Set developers.



8. Train Set Compatibility
================================================================================
The Metro Track Set is known to work with a few train sets that supply metro
vehicles. For each train set, the recommended setting for the second parameter 
(see section 5.2) is listed in the table below. If your favourite train set,
containing metro vehicles, is not listed below that does not mean that the Metro
Track Set doesn't work with it! It just means that no recommended parameter
setting is listed!

-------------------------------------------------------------------
|Train Set and Version                     |Second parameter value|
-------------------------------------------------------------------
| 2cc Trainset 2.0.0-Beta3                 | 16                   |
| UK Railway Set (UKRS2) Public Alpha 0.41 | 0 (OpenTTD only)     |
-------------------------------------------------------------------

Note: a recommended setting of 0 is equal to not setting the parameter.



9. Upgrading From Previous Version
================================================================================
If you are upgrading from a previous version of the Metro Track Set, you should
disable all previous versions of Metro Track Set that you have active. If you
neglect to do so, the newest version of Metro Track Set will disable itself.

OpenTTD users who are upgrading Metro Track Set in a running game are required
to set the second parameter (see section 5.2) in order to maintain the original 
behaviour of Metro Track Set. In short: set parameters to 0 1 to get OpenGFX 
style graphics or set parameters to 1 1 to get TTD style graphics.



A. Credits
================================================================================
Metro Track Set developer:
  Jasper Vries (FooBar)     - coding, general graphics manipulation, OpenGFX 
                              support

Inactive developers:
  Purno                     - idea, third rail graphics

Thanks to:
  XeryusTC                  - initial release
  Thomas Mjelva (DJ Nekkid) - saving the set's future by taking over development
                              and handing it over to FooBar shortly after

The set contains (parts of) graphics and code by others:
TTD graphics:               Simon Foster.
OpenGFX Track graphics:     Zepyris (Richard Wheeler).
OpenGFX Bridge graphics:    Zimmlock, Thgergo, Purno and Zephyris.
OpenGFX GUI graphics:       Bubersson and LordAzamath and Zephyris.
Makefile build system:      planetmaker



B. Frequently Asked Questions
================================================================================
Q: The colours of the tracks look weird!
A: That's not a question, but if the graphics have a lot of brownish/pinkish
pixels in them, then you are using the DOS version of the base graphics. In
OpenTTD, open the NewGRF configuration window, select the Metro Track Set and
use the option to toggle the palette. This will give you the correct colours.
TTDPatch users will have to decode the grf and then recode it using a palette
translation using GRFCodec.

Q: The Metro Tracks are not buildable, why is that?
A: The Metro Tracks are only availabe if there are metro vehicles available.
These metro vehicles must be provided by a third-party vehicle set and are not
available by default in OpenTTD.

Q: My metro vehicles are running on some other track than the Metro Tracks, can
you fix that?
A: You can easily fix that yourself using the parameter options as described in
section 5, allowing the Metro Tracks to replace either the maglev or the
monorail tracks.

Q: Can I use a train set that has metro vehicles on monorail and a train set
that has metro vehicles on third rail or maglev at the same time?
A: No, you can't.

Q: Why do the labels for Metro Track still say monorail/maglev?
A: In OpenTTD it is not possible to change those texts without using railtypes.
Either upgrade your OpenTTD, set that you want to use railtypes instead or just
live with it.

Q: Why is this readme so big?
A: There is a lot to write about.

Q: Why are the 3rd Rail tracks in a different position in the list when using
Metro Track Set with NuTracks when compared to NuTracks alone?
A: Load Metro Track Set after NuTracks to keep NuTracks' track order. Observe
the big red warning when you try to do that in a running game and don't complain
if you have to convert all your 3rd rail tracks after doing so.

Q: Where can I ask a question that is not listed here?
A: Feature requests and bug reports go into the Metro Track Set Development
topic at TT-Forums.net: http://www.tt-forums.net/viewtopic.php?t=49404. 
Compliments and questions about getting the set to work go in the Metro Track 
Release topic: http://www.tt-forums.net/viewtopic.php?t=49476.



C. Obtaining the Source
================================================================================
The Metro Track Set source code is available in a Mercurial repo located at
http://hg.openttdcoop.org/metrotrackset. This repository can be browsed without
the need of Mercurial via 
http://dev.openttdcoop.org/projects/metrotrackset/repository.

Alternatively, the sources of releases are also available as gzipped tarballs at
http://bundles.openttdcoop.org/metrotrackset/releases/.

Building Metro Track Set from source requires:
* GRFCodec (http://www.openttd.org/en/download-grfcodec)
* NFORenum (http://www.openttd.org/en/download-nforenum)
* A C precompiler (gcc recommended)

Using the supplied makefile also requires a number of UNIX utilities such as
make, grep, sed, etc. (etc is not a tool, it just means more tools needed).
More details and the source of the makefile system are available at:
http://dev.openttdcoop.org/projects/newgrf-makefile, in particular the system's
readme available in it's source repository.

Without using the makefile, you need to run /sprites/nfo/metrotrk.pnfo through
the C precompiler saving the result to /sprites/metrotrk.nfo. Then run this
result through NFORenum and running GRFCodec from / creating metrotrk.grf.
