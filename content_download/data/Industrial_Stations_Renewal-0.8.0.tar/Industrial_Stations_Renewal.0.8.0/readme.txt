Industrial Stations Renewal v0.8.0
==================================

Industrial Stations Renewal Readme
----------------------------------

Industrial Stations Renewal is a set of stations for TTDPatch and OpenTTD. It includes stations and facilities suitable for freight cargo. It includes support for the standard TTD industries plus many of the additional industry GRFs.

Features include animation of the various cranes and warehouse doors etc. Most animations are triggered by activity at the station, such as trains arriving/leaving and cargo being delivered. Platforms and non-track tiles are included that display the amount of cargo waiting at the station.

 

TTDPatch/OpenTTD Version Requirements
-------------------------------------

TTDPatch

Version required: 2.6 alpha r1683

# Required patch settings: newstations on

# Recommended patch settings: irregularstations on
# largestations on

 

OpenTTD

Version required: 0.6.1 or nightly build from r12674 onwards

Animated stations are only supported by OpenTTD since nightly build r12798. In earlier versions, including 0.6.3, the stations can still be used but they won't be animated.

 

Parameters
----------

The first parameter controls the docks, the second controls the ship depot. In both cases '0' enables the new graphics, '1' disables then.

# The third parameter controls track overlays used by the mineral unloader station and the road crossing. Different overlays are used depending on the track type (normal rail, monorail or maglev). When a GRF that replaces monorail or maglev is being used, the normal rail overlay is usually required. In the case of narrow gauge rails (ngrails[w].grf), the Canadian Trainset (canset[w].grf) and metro rails (metro.grf) the GRF is detected and the correct overlay is used. For compatibility with other track replacement GRFs, the parameter allows the overlays for the monorail and/or maglev track slots to be set to suit. The settings are: 0 (default) - use monorail and maglev overlays.
# 1 - use normal rail overlays for the monorail slot.
# 2 - use normal rail overlays for the maglev slot.
# 3 - use normal rail overlays for both the monorail and maglev slots.

With no parameters set they default to '0 1 0' i.e. new docks enabled, ship depot disabled, standard track overlays used.

 

Animated Stations
-----------------

Animations that span multiple tiles (overhead crane, gantry cranes etc.) require some special considerations when modifying the station. If over-building or removing tiles from an animation, it is advisable to remove or overbuild all the tiles of the animation (i.e. the whole platform). Graphical errors may occur otherwise.

Note: station animation requires OpenTTD r12798 or greater. It is not supported by 0.6.3.

# Stations and station tiles that are animated: Goods station A
# Steel mill station
# Tower crane
# Crane on rails
# Overhead crane
# Gantry crane (modern)
# Gantry crane (classic)
# Conveyor belt (minerals)
# Main office
# Shipping office
# Large warehouse
# Small warehouse
# Modern warehouse
# Brick warehouse
# Front loader (minerals)
# Forklift (crates)
# Forklift (containers)

 

PBS Controlled Doors.
---------------------

Some buildings such as the engine sheds and valuables sheds, have doors controlled by PBS (Path Based Signalling). The doors will also remain closed if no rails are connected.

In cases where PBS is disabled, the doors open when a rail, a station platform or a buffer is connected to the shed door.

If PBS is enabled, in addition to requiring a connecting rail, the doors only open when the track is reserved. For this to work, always build a PBS signal on the track leading to the building, otherwise the track will not be reserved and the door will remain closed.

 

Buffers.
--------

The north/south orientation of the buffers is automatically controlled by the direction of connected rails or platforms. If there is a track that the buffer can connect to, it will orientate itself in the direction of the track. If there is track both sides of the buffer, a back-to-back double buffer will be used.

 

Truck Parking.
--------------

The truck parking tiles display trucks depending on the amount of cargo waiting at the station. Truck parking tiles will only work if built with normal or electrified rail types selected. In TTDPatch the truck parking will not appear in the purchase list if monorail or maglev are selected.

OpenTTD does not currently support querying of the rail tool type, consequently truck parking tiles are not disabled for monorail or maglev, but they will not display any trucks. It is therefore recommended to always change to normal or electrified rail before building truck parking tiles.

 

Cargo Display on Station Tiles
------------------------------

This list shows the types of cargo that must be present at a station, in order for that station to display cargo on its platforms. Note, no attempt has been made to restrict which types of cargo a station will accept. All industrial stations behave as normal stations as far as the game is concerned.

Cargos included in this list are those (or their packaging - containers etc.) that are displayed graphically. Cargos not on this list are those that would be stored in silos, tanks etc.

# Mineral silo/Mineral piles/Mineral platforms (show cargo type dependant graphics) coal
# iron ore
# copper ore
# clay
# gravel
# limestone
# sand

# Livestock station/Pig yard/Cattle docks/Cattle sheds livestock

# Wood loading station/Wood platforms/Wood piles wood
# tropic wood

# Oil Storage Tanks (level indication only) oil
# petrol
# refined products

# Steel mill station steel

# Goods stations (before 1960)/General cargo platforms/General cargo tiles mail
# goods
# paper
# food
# fruit
# fish
# wool
# glass
# ceramics

# Goods stations/Container loading platforms/Container tiles (post 1960) mail
# goods
# paper
# food
# fruit
# fish
# wool
# glass
# ceramics
# bricks
# vehicles

# Steel platforms/Steel tiles steel

# Copper platforms/Copper tiles copper
# goods (if copper is not available as a specific cargo)

# Barrel platforms/Barrel tiles oil
# goods
# water
# rubber
# petrol
# fertiliser
# dyes
# refined products
# plastic

# Plank platforms/Plank tiles wood products
# lumber
# goods (if neither wood products nor lumber is available as a specific cargo)

# Car tiles vehicles
# goods (if vehicles are not available as a specific cargo)

 

Bug Reports
-----------

Please report any bugs found to the Transport Tycoon forum in the Industrial Stations Renewal topic.

 

Licensing
---------

Industrial Stations Renewal is licensed under the GNU General Public License version 2.

Industrial Stations Renewal for TTDPatch and OpenTTD.

Copyright � 2006-2008 the ISR contributors (see credits).

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

 

Some graphics used for Industrial Stations Renewal are based on graphics originating from the Industrial Stations Set v0.98 (jcindsta[w].grf):

The Industrial Stations Set is licensed under the GNU General Public License version 2.

The Industrial Stations Set for TTDPatch
Copyright � 2005 by certain members of the Transport Tycoon Forums (norfolksouthern37, Arte Pro 34, Oz and Oracle)

 

Change Log
----------

v0.8.0
# Crawler crane added.
# Mining truck added - shows minerals.
# Bulldozer (minerals) added - shows minerals.
# Front loader (minerals) added - animated, shows minerals.
# Log loader added - shows wood.
# Log stacker added - shows wood.
# Forklift (crates) added - animated, shows crates.
# Forklift (containers) added - animated, shows containers.
# Reach stacker added - shows containers.
# Container stacker added - shows containers.
# Small forklifts changed to medium forklifts for goods station B.
# Bulldozer graphics updated with new version (wood station and mineral conveyors).
# Sprites for timber (was 'planks') platforms and non-track tiles replaced.
# Sprites for copper/steel non-track tiles replaced.
# Copper is now re-coloured to steel instead of using separate sprites.
# Some container colours changed to remove the excess of red on non-track tiles.
# Mineral piles (non-track) now use re-colour sprites for mineral colours.
# Mineral piles (non-track) graphics updated.
# Mineral silo/mineral platforms now use re-colour sprites for mineral colours.
# Mineral silo/mineral platforms graphics updated.
# Mineral silo layout updated. Silo building is now one tile from end and repeated at intervals for long stations.
# Mineral unloader is now compatible with maglev/monorail.
# Road crossing is now compatible with maglev/monorail.
# Parameter added to control mineral unloader and road crossing graphics when using a replacement track grf.
# Dutch translation added.
# Fix: Orientation of facilities buildings was incorrect.
# Fix: Gravel platform sprite offset error.
# Fix: Empty wood platforms were not showing desert/snow.

v0.7.1
# Forklifts changed to new small forklift (goods station B, valuables station and valuables parking).
# Wood station diggers replaced with crawler crane and bulldozer.
# Train shed height reduced.
# Platform ramp graphics updated.
# French and Estonian translations added.
# TTDPatch version test changed to 2.6 alpha r1683.
# Fix: Incorrect container positions on non-track tiles.
# Fix: Wires/gantry not shown on goods and valuables stations.
# Fix: Incorrect orientations for conveyor N.

v0.7.0
# New station class added; 'Industrial: Stations', all existing pre-built stations can now be found here.
# Grain loading station - based on old Farm facilities, but has been completely updated.
# Livestock station - new station - displays livestock.
# Mineral unloader - extensive upgrade to original mineral unloader.
# Wood loading station - new station - displays wood.
# Valuables station - new station .
# Goods station A - new station - displays crates or containers.
# Goods station B - new station - displays crates or containers.
# Steel mill station - now with animated overhead cranes and other updates.
# Translations added: German, Spanish, and Finnish.
# Separate mineral platforms added.
# All road tiles updated, including automatically generated junctions, rail crossings and access ramps.
# New road entry tile added.
# Truck parking, now displays truck types dependant on cargo type waiting and game year.
# New Containers with crane non-track tile added - animated crane.
# Container platforms updated with new containers.
# Containers non-track, now ground-level and updated with new containers.
# Processed cargo platforms now show more variation.
# Non-track processed cargo tiles are now ground level.
# New Cars cargo tiles added - display cars when goods or vehicles are waiting.
# New farm building added 'Small farm building'.
# Valuables shed door now remains closed when there is no connecting rail or buffer.
# Train shed door now remains closed when there is no connecting rail or buffer.
# Buffers now use automatic orientation, depending on direction of connecting rails.
# Platform ramps fences removed.
# Marshalling yard (was 'Switchyard') buffers now aware of tiles that do not have middle rail.
# Conveyor orientations swapped.
# Train loading chute (was 'Tipple') can now be built with platform widths greater than 1.
# Water tower can now be built with platform widths greater than 1.
# Valuables parking now uses random cargo display threshold (forklift trucks).
# Valuables parking changed to transparent base tile.
# Changes made to multi-tile animation code. Now less likely for the crane animations to de-sync when over-built.
# Randomisation of farm building types now works when over-building.
# Farm building now displays empty tile if one half is removed.
# OpenTTD version updated.
# Renamed 'Switchyard' to 'Marshalling yard'.
# Renamed 'Tipple' to 'Train loading chute'.
# Fix: Cattle docks showing no fence on track side when there is another cattle dock platform to the north.
# Fix: Wood non-track tile spite size error.
# Fix: Train shed and Valuables shed closed door sprite was shown behind train when shed is entered from far end.
# Fix: Valuables unloaders not joining together properly.
# Fix: Train shed was showing grass inside.

v0.6.3
# Increased animation speed for overhead crane.
# Removed limits for build size of oil storage facility.
# Gantry cranes now use re-colour sprites
# Fix: Sprite offset error in modern gantry crane (only south facing cranes in NW-SE direction affected).
# Fix: Farm building broken when built on snow/desert.
# Fix: Farm facilities, farm building, mineral silo and mineral unloader all showing incorrect sprites when built on snow/desert (TTDPatch only).
# Fix: Cattle sheds showing wrong ground sprite when built using maglev/monorail rail types.
# Fix: Offices and offices modern (ground level) not showing desert/snow.
# Fix: Parameter default values not working as intended.

v0.6.2
# Randomised cargo level thresholds added.
# Fix: Mineral unloader base sprites flickering.
# Fix: Flickering of back sprites on grain silo with odd number of platforms.
# Fix: Non-track coal piles not showing randomisation or snow.
# Fix: Mineral silo platforms were sometimes not showing the correct ground sprite on desert and snow.

v0.6.1
# Fix: Mineral silo coal platform sprite misalignment.
# Fix: Valuables sheds showing normal rail with maglev/monorail.
# Fix: Steel mill station sprite glitch.

v0.6.0
# Animated gantry cranes added, with classic and modern versions in both track and non-track types .
# Steel mill station added.
# General cargo (crate) platforms and non-track tiles.
# Additional stages of cargo levels on minerals platforms and non-track tiles.
# Improved control of levels of cargo displayed on most cargo track and non-track tiles.
# Support for newcargos, including ECS and PBI cargos.
# New animations added, including doors of various facility buildings and the tower crane.
# Bug fixes: various.

 

Credits
-------

Graphics by:

    * Sanchimaru
    * Oz
    * norfolksouthern37
    * Zimmlock
    * Ben_K
    * Born Acorn
    * mph
    * Arte Pro 34
    * andythenorth

Coded by:

    * Maedhros
    * mart3p

Translations by:

    * Spanish - Sanchimaru, maquinista
    * German - Aylo, zypa
    * Finnish - Vemarkis
    * French - cmoiromain, Wallyweb
    * Estonian - Alselius
    * Dutch - Foobar

